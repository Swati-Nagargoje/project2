echo "CHANGE DIRECTORY TO GIT CODE LOCATION"
cd "/c/home/Shop/"
echo "PULLING THE LATEST SHOP HTML CODE"
git pull

cd "/c/home/ShoppingCart/"
echo "PULLING THE STOREADMIN AND STOREFRONT"
git pull

echo "PULL COMPLETED......"
rm -rf /c/sw/xampp/htdocs/shop/*
cp -p -r /c/home/Shop/* /c/sw/xampp/htdocs/shop/
echo "COPIED TO SHOP FOLDER NOW"
rm -rf /c/sw/xampp/htdocs/storefront/*
cp -p -r /c/home/ShoppingCart/storefront/* /c/sw/xampp/htdocs/storefront/
echo "COPIED TO STOREFRONT FOLDER NOW"
rm -rf /c/sw/xampp/htdocs/storeadmin/*
cp -p -r /c/home/ShoppingCart/storeadmin/* /c/sw/xampp/htdocs/storeadmin/
echo "COPIED TO STOREADMIN FOLDER NOW"

