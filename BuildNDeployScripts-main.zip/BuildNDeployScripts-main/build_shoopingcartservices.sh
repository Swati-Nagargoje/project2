export JAVA_HOME=${JAVA_HOME}
echo $JAVA_HOME
export PATH=/c/sw/java/jdk-14.0.2/bin:${PATH}
echo $PATH

echo "COMMON CODE BUILD"
cd /c/home/A2ZCommonCode/
echo "PULLING THE LATEST COMMON CODE"
git pull
echo "STARTING TO BUILD THE COMMON CODE......."
mvn clean install
echo "CODE BUILD COMPLETED......"
cp -p /c/home/A2ZCommonCode/target/common-0.0.1-SNAPSHOT.jar /c/home/Deploy/

echo "CHANGE DIRECTORY TO GIT CODE LOCATION"
cd /c/home/ShoopingCartServices/
echo "PULLING THE LATESTSHOOPING CART SERVICES CODE"
git pull
echo "STARTING TO BUILD THE CODE......."
mvn clean install
echo "CODE BUILD COMPLETED......"
cp -p /c/home/ShoopingCartServices/target/Shop-1.0.0.1-SNAPSHOT.jar /c/home/Deploy/
echo "BUILT JAR COPIED TO CURRENT LOCATION..START NOW"
