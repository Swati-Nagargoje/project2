export JAVA_HOME=${JAVA_HOME}
echo $JAVA_HOME
export PATH=/c/sw/java/jdk-14.0.2/bin:${PATH}
echo $PATH
echo "CHANGE DIRECTORY TO GIT CODE LOCATION"
cd /c/home/StoreFrontAPI/
echo "PULLING THE LATEST StoreFrontAPI CODE"
git pull
echo "STARTING TO BUILD THE CODE......."
mvn clean install
echo "CODE BUILD COMPLETED......"
cp -p /c/home/StoreFrontAPI/target/ShopAPIGateway-1.0.0.1-SNAPSHOT.jar /c/home/Deploy/
echo "BUILT JAR COPIED TO CURRENT LOCATION..START NOW"
