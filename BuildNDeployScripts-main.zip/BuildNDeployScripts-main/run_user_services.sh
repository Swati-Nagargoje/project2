#!/usr/bin/bash

echo "Starting Services..."

cd /c/home/UserAPI/

SPRING_PROFILES_ACTIVE=qa mvn spring-boot:run
