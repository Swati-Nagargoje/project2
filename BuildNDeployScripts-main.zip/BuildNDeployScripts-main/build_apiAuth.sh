export JAVA_HOME=${JAVA_HOME}
echo $JAVA_HOME
export PATH=/c/sw/java/jdk-14.0.2/bin:${PATH}
echo $PATH
echo "CHANGE DIRECTORY TO GIT CODE LOCATION"
cd /c/home/AuthenticationAPI/
echo "PULLING THE LATESTSHOOPING CART SERVICES CODE"
git pull
echo "STARTING TO BUILD THE CODE......."
mvn clean install
echo "CODE BUILD COMPLETED......"
cp -p /c/home/AuthenticationAPI/target/AuthenticationAPI-1.0.0.1-SNAPSHOT.jar /c/home/Deploy/
echo "BUILT JAR COPIED TO CURRENT LOCATION..START NOW"
