#!/usr/bin/bash
echo "Starting APIGateway..."
export TITLEPREFIX="SHOPAPIGWAY"

cd /c/home/ShopAPIGateway/
SPRING_PROFILES_ACTIVE=qa mvn spring-boot:run