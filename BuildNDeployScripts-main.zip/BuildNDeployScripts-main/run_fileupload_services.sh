#!/usr/bin/bash

echo "Starting Services..."

cd /c/home/FileUploadAPI/

SPRING_PROFILES_ACTIVE=qa mvn spring-boot:run
