#!/bin/bash

sh run_apigw.sh &>> logs/apigw.log &
sh run_auth_services.sh &>> logs/auth.log &
sh run_fileupload_services.sh &>> logs/fileUpload.log &
sh run_registration_services.sh &>> logs/reg_api.log &
sh run_storeadmin_services.sh &>> logs/storeAdmin.log &
sh run_storefront_services.sh &>> logs/storeFront.log &
sh run_user_services.sh &>> logs/user.log &
