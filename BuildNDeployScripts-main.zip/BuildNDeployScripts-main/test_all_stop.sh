#!/bin/bash
taskkill //F //PID "$(jps | grep ShopApi* | awk '{print $1}')"  &>>  logs/test_all_stop.log
taskkill //F //PID "$(jps | grep Authen* | awk '{print $1}')"  &>>  logs/test_all_stop.log
taskkill //F //PID "$(jps | grep File* | awk '{print $1}')"  &>>  logs/test_all_stop.log
taskkill //F //PID "$(jps | grep Regis* | awk '{print $1}')"  &>>  logs/test_all_stop.log
taskkill //F //PID "$(jps | grep StoreAdmin* | awk '{print $1}')"  &>>  logs/test_all_stop.log
taskkill //F //PID "$(jps | grep StoreFront* | awk '{print $1}')"  &>>  logs/test_all_stop.log
taskkill //F //PID "$(jps | grep User* | awk '{print $1}')"  &>>  logs/test_all_stop.log
