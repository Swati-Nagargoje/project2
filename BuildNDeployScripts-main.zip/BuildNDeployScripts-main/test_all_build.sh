#!/bin/bash
sh build_apigw.sh &>> logs/all_build_and_run.log  && printf "\n"
printf "apigw"

sh build_apiAuth.sh &>> logs/all_build_and_run.log  && printf "\n"
printf "auth"

sh build_registrationapi.sh  &>> logs/all_build_and_run.log
printf "reg"

sh build_fileuploadapi.sh  &>> logs/all_build_and_run.log
printf "fileupload"

sh build_userapi.sh  &>> logs/all_build_and_run.log
echo "user"

sh build_storefront.sh  &>> logs/all_build_and_run.log
echo "storefrontapi \n\n"

sh build_storeadmin.sh  &>> logs/all_build_and_run.log
echo "storeadminapi \n\n"