echo "Starting Authentication Services..."
export TITLEPREFIX="SHOPAPIGWAY"

cd /c/home/AuthenticationAPI/

SPRING_PROFILES_ACTIVE=qa mvn spring-boot:run


